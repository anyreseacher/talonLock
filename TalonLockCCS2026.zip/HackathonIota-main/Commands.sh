iota client call \
--package 0x9a80f8d5de67c65b0dbe4e38cfff9624f35ee9705a2def73fd0d6a7e156ea161 \
--module ExampleCoin --function mint \
--type-args 0x9a80f8d5de67c65b0dbe4e38cfff9624f35ee9705a2def73fd0d6a7e156ea161::ExampleCoin::EXAMPLECOIN \
--args 0x5fa966827fe9181a65a14e110b15097c02693b25fcd475ed19d053ed706cabcd 1000 \
--gas-budget 5000000

iota client call \
--package 0x1cec6db2e3f3f53cbbd40595df3a935e11ae723512fd7eb9f0d0620f07bd2727 \
--module vesting \
--function create_vester \
--type-args 0x9a80f8d5de67c65b0dbe4e38cfff9624f35ee9705a2def73fd0d6a7e156ea161::ExampleCoin::EXAMPLECOIN \
--args 1726591072957 100 100 \
--gas-budget 50000000


iota client transfer \
--to 0x80521e66ec6b52266a7da9d08458a9c4ddd882445f4cc061af901275af495e57 \
--object-id 0x12b0de169e8aebd130683fd9b8bf1ce7867bd69d22d06fd85db4ace46cab863b \
--gas-budget  50000000


iota client call \
--package 0x1cec6db2e3f3f53cbbd40595df3a935e11ae723512fd7eb9f0d0620f07bd2727 \
--module vesting \
--function initialize_vester \
--type-args 0x9a80f8d5de67c65b0dbe4e38cfff9624f35ee9705a2def73fd0d6a7e156ea161::ExampleCoin::EXAMPLECOIN \
--args 0x80521e66ec6b52266a7da9d08458a9c4ddd882445f4cc061af901275af495e57 0x12b0de169e8aebd130683fd9b8bf1ce7867bd69d22d06fd85db4ace46cab863b  \
--gas-budget 50000000


iota client call \
 --package 0x1cec6db2e3f3f53cbbd40595df3a935e11ae723512fd7eb9f0d0620f07bd2727 \
 --module vesting --function release \
 --type-args 0x9a80f8d5de67c65b0dbe4e38cfff9624f35ee9705a2def73fd0d6a7e156ea161::ExampleCoin::EXAMPLECOIN \
 --args 0x80521e66ec6b52266a7da9d08458a9c4ddd882445f4cc061af901275af495e57 0x0000000000000000000000000000000000000000000000000000000000000006  \
 --gas-budget 50000000



iota client call \
 --package 0x1cec6db2e3f3f53cbbd40595df3a935e11ae723512fd7eb9f0d0620f07bd2727 \
 --module vesting --function collect_not_vested_coins \
 --type-args 0x9a80f8d5de67c65b0dbe4e38cfff9624f35ee9705a2def73fd0d6a7e156ea161::ExampleCoin::EXAMPLECOIN \
 --args 0x80521e66ec6b52266a7da9d08458a9c4ddd882445f4cc061af901275af495e57  \
 --gas-budget 50000000

