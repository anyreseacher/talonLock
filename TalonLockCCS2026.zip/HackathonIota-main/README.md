# Vesting Contract Module - `ctf::vesting`

## Overview

This module defines a vesting contract for token distribution over time, providing functionality for time-based and event-based release of vested tokens to users. It allows the vesting of tokens according to linear or dynamic strategies, including strategies based on users' holdings of other tokens. The contract is designed to handle time-based vesting schedules and dynamic allocation of tokens to users.

## Features

- **Error Handling**: The module includes specific error codes for various conditions (e.g., insufficient funds, invalid strategy, premature release).
- **Vesting Strategies**: Supports multiple strategies such as linear, dynamic key-value, and coin-based distributions.
- **Time-Based Vesting**: Supports vesting based on fixed time frames or duration.
- **Custom Allocation**: Allows administrators to allocate specific amounts of tokens to individual users.

## Error Codes

The module defines several error codes for assertion failures throughout the contract:

| Error Code                | Description |
| ------------------------- | ----------- |
| `ERROR_INVALID_DURATION`   | Invalid vesting duration (e.g., `duration <= 0`) |
| `ERROR_INSUFFICIENT_FUNDS` | Insufficient funds to release or collect |
| `ERROR_TOO_EARLY_RELEASE`  | Attempt to release funds before the vesting period |
| `ERROR_NOT_ADMIN`          | Non-administrator tries to perform restricted actions |
| `ERROR_INVALID_STRATEGY`   | Invalid or unsupported vesting strategy |
| `ERROR_INVALID_LENGTH`     | Mismatched vector lengths between time frames and percentages |
| `ERROR_INVALID_VESTING_PARAMETERS` | Both duration and time frames are missing, making vesting configuration invalid |
| `ERROR_INVALID_TIME_FRAME_PARAMETERS` | Invalid time frame parameters (e.g., empty frames, zero percentages) |
| `ERROR_VESTING_NOT_ENDED`  | Attempt to collect non-vested funds before vesting period ends |

## Structs

### `TimeFrame`
Defines a vesting schedule where a certain percentage of tokens are released at a specific time.

- `time: u64` – The timestamp for the release of tokens.
- `percentage: u8` – The percentage of the total amount to be released.

### `AmountTo`
Represents the amount of tokens vested to a user.

- `user: address` – Address of the user receiving vested tokens.
- `amount: u64` – Amount of tokens vested to the user.

### `StrategyType<Type>`
Defines the strategy for vesting.

- `id: UID` – Unique identifier for the strategy.
- `id_strategy: u8` – Type of strategy (1: linear, 2: dynamic, 3: coin-based).
- `amount_each: u64` – The amount to be vested per user for linear strategies.

### `Vesting<Asset, StrategyType>`
Represents a vesting contract.

- `id: UID` – Unique identifier for the vesting contract.
- `coin: Balance<Asset>` – The balance of tokens in the contract.
- `supply: u64` – The total amount of tokens provided for vesting.
- `start: u64` – The start timestamp for vesting.
- `administrator: address` – The contract administrator's address.
- `total_vested: u64` – Total amount of tokens vested so far.
- `strategy: StrategyType` – Vesting strategy.
- `duration: Option<u64>` – Vesting duration in seconds.
- `time_frames: Option<vector<TimeFrame>>` – List of time frames for vesting.

## Functions

### `create_strategy_not_for_coin`
Creates a vesting strategy that is not based on a coin balance.

- `id_strategy: u8` – Type of strategy (1: linear, 2: dynamic).
- `amount_each: u64` – Amount of tokens to vest per user.
- `ctx: &mut TxContext` – Transaction context.

### `create_strategy_for_coin`
Creates a coin-based vesting strategy.

- `id_strategy: u8` – Type of strategy (must be 3).
- `amount_each: u64` – Amount to vest per user.
- `ctx: &mut TxContext` – Transaction context.

### `create_vester`
Creates a new vesting contract.

- `start_timestamp: u64` – Vesting start time.
- `strategy: StrategyType<Type>` – Vesting strategy.
- `duration_seconds: Option<u64>` – Vesting duration.
- `times_: Option<vector<u64>>` – Optional time frames.
- `percentages_: Option<vector<u8>>` – Optional percentages corresponding to time frames.
- `ctx: &mut TxContext` – Transaction context.

### `initialize_vester`
Initializes a vesting contract with funds to be vested.

- `_vester: &mut Vesting<Asset, StrategyType<Type>>` – Vesting contract.
- `_to_vest: Receiving<Coin<Asset>>` – Coins to be vested.
- `ctx: &mut TxContext` – Transaction context.

### `release_coins`
Releases vested tokens to users based on time-based schedules.

- `_vester: &mut Vesting<Asset, StrategyType<u64>>` – Vesting contract.
- `_clock: &Clock` – Clock for tracking time.
- `ctx: &mut TxContext` – Transaction context.

### `release_coins_by_coinbase`
Releases vested tokens based on a coin-based vesting strategy.

- `vester: &mut Vesting<Asset, StrategyType<BaseCoin>>` – Vesting contract.
- `clock: &Clock` – Clock for time tracking.
- `coinList: vector<Coin<BaseCoin>>` – List of coins for vesting.
- `ctx: &mut TxContext` – Transaction context.

### `add_supply_of_coin`
Adds more coins to the vesting contract's supply.

- `vester: &mut Vesting<Asset, StrategyType<Type>>` – Vesting contract.
- `to_vest: Receiving<Coin<Asset>>` – Coins to be added.
- `ctx: &mut TxContext` – Transaction context.

### `collect_not_vested_coins`
Collects non-vested tokens after the vesting period ends.

- `vester: &mut Vesting<Asset, StrategyType<Type>>` – Vesting contract.
- `clock: &Clock` – Clock for time tracking.
- `ctx: &mut TxContext` – Transaction context.

### `set_allocate_amount_per_user`
Allocates custom amounts of tokens to each user dynamically.

- `vester: &mut Vesting<Asset, StrategyType<Type>>` – Vesting contract.
- `users: vector<address>` – List of users.
- `amounts: vector<u64>` – Corresponding amounts for each user.
- `ctx: &mut TxContext` – Transaction context.

## Internal Functions

### `validate_time_frames`
Validates the time frames for vesting.

### `get_frame_base_releasable_amount`
Calculates the amount of tokens releasable based on the vesting schedule.

### `get_amount_for_user`
Retrieves the total amount vested for a specific user based on the strategy.

### `get_released_amount_to_user`
Gets the amount of tokens already released to the user.

### `get_linear_releasable_amount`
Calculates the releasable amount based on a linear vesting strategy.

### `send_to_user_and_update_vester`
Sends releasable tokens to the user and updates the vesting record.

### `has_vesting_ended`
Checks if the vesting period has ended.